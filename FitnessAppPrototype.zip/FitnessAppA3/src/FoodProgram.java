import javax.swing.*;
import java.awt.*;

public class FoodProgram {

    }

