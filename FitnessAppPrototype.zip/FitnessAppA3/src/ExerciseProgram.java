public class ExerciseProgram {
}
